package com.service.ribbon;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaServiceWithRibbonApplicationTests {

	@Test
	void contextLoads() {
	}

}
