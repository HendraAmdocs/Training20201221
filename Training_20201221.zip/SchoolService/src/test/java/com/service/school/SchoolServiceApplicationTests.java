package com.service.school;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
