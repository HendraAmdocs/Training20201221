package com.javatpoint.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.model.Book;
import com.javatpoint.repository.BooksRepository;

@Service
public class BooksService {

	@Autowired
	BooksRepository booksRepository;
	
	public List<Book> getAllBooks() {
		List<Book> books = new ArrayList<Book>();
		this.booksRepository.findAll().forEach(book -> books.add(book));
		return books;
	}
	
	public Book getBook(int bookId) {
		return this.booksRepository.findById(bookId).get();
	}
	
	public void deleteBook(int bookId) {
		this.booksRepository.deleteById(bookId);
	}
	
	public void saveOrUpdateBook(Book book) {
		this.booksRepository.save(book);
	}
	
	public void updateBook(Book book, int bookId) {
		this.booksRepository.save(book);
	}
	
	public List<Book> getBookByPriceRange(int priceStart, int priceEnd) {
		List<Book> books = new ArrayList<Book>();
		this.booksRepository.findAll().forEach(book -> {
			if (book.getPrice() >= priceStart && book.getPrice() <= priceEnd) {
				books.add(book);
			}
		});
		return books;
	}
	
}
