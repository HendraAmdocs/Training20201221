package com.javatpoint.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.javatpoint.model.Book;
import com.javatpoint.service.BooksService;

@RestController
public class BooksController {
	@Autowired
	private BooksService booksService;
	
	@GetMapping("/books")
	public List<Book> getAllBooks() {
		return this.booksService.getAllBooks();
	}
	
	@GetMapping("/books/{bookId}")
	public Book getBook(@PathVariable("bookId") int bookId) {
		return this.booksService.getBook(bookId);
	}
	
	@DeleteMapping("/books/{bookId}")
	public void deleteBook(@PathVariable("bookId") int bookId) {
		this.booksService.deleteBook(bookId);
	}
	
	@PostMapping("/books")
	public int saveBook(@RequestBody Book book) {
		this.booksService.saveOrUpdateBook(book);
		return book.getBookId();
	}
	
	@PutMapping("/books")
	public Book updateBook(@RequestBody Book book) {
		this.booksService.saveOrUpdateBook(book);
		return book;
	}
	
	@GetMapping("/books/{priceStart}/{priceEnd}")
	public List<Book> getAllBooks(@PathVariable("priceStart") int priceStart, @PathVariable("priceEnd") int priceEnd) {
		return this.booksService.getBookByPriceRange(priceStart, priceEnd);
	}
	
}
