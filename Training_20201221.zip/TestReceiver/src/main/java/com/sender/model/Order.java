package com.sender.model;

import java.io.Serializable;

public class Order implements Serializable {

	private int id;
	private String item;
	private int price;
	private Address address;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		if (!item.equalsIgnoreCase("") && item != null) {
			this.item = item;
		} else {
			throw new IllegalStateException("Item is empty.");
		}
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		if (price >= 0) {
			this.price = price;
		} else {
			throw new IllegalStateException("Price is wrong.");
		}
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String toString() {
		String rVal = "id: " + this.getId() + "\n" + "item: " + this.getItem() + "\n" + "price: " + this.getPrice() + "\n"
				+ "address: " + this.getAddress().getState() + ", " + this.getAddress().getPin() + ".";
		return rVal;
	}

}
