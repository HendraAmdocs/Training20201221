package com.sender.model;

import java.io.Serializable;

public class Address implements Serializable {

	private static final long serialVersionUID = 8276144194388565480L;

	private String state;
	private String pin;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		if (!state.equalsIgnoreCase("") && state != null) {
			this.state = state;
		} else {
			throw new IllegalStateException("State is empty.");
		}
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		if (!pin.equalsIgnoreCase("") && pin != null) {
			this.pin = pin;
		} else {
			throw new IllegalStateException("PIN is empty.");
		}
	}

}
