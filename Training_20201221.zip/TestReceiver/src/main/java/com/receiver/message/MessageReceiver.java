package com.receiver.message;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.sender.model.Order;

@Component
public class MessageReceiver {
	private static final String MESSAGE_QUEUE = "order_queue";

	@JmsListener(destination = MESSAGE_QUEUE)
	public void receiveMessage(Order order) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("--------------------------------------------------------------------------------");
		System.out.println("Received order:\n" + order);
		System.out.println("--------------------------------------------------------------------------------");
	}

	@JmsListener(destination = "queue2")
	public void receiveMessageFromQueue2(Order order) {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Received " + order);
	}

}
