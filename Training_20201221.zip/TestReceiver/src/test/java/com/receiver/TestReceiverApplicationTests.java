package com.receiver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestReceiverApplicationTests {

	@Test
	void contextLoads() {
	}

}
