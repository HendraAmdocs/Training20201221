package com.sender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
