package com.sender.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sender.model.Order;
import com.sender.service.TestSenderService;

@RestController
public class TestSenderController {

	@Autowired
	TestSenderService testSenderService;
	
	@PostMapping("/orders")
	public String sendOrder(@RequestBody Order order) {
		return this.testSenderService.saveOrUpdateOrder(order);
	}

	@GetMapping("/orders")
	public List<Order> getAllOrders() {
		return this.testSenderService.getAllOrders();
	}
	
	@GetMapping("/orders/{id}")
	public Order getOrder(@PathVariable("id") int id) {
		return this.testSenderService.getBook(id);
	}
	
	@DeleteMapping("/orders/{id}")
	public void deleteBook(@PathVariable("id") int id) {
		this.testSenderService.deleteOrder(id);
	}
	
	@GetMapping("/orders/{priceStart}/{priceEnd}")
	public List<Order> getAllOrders(@PathVariable("priceStart") int priceStart, @PathVariable("priceEnd") int priceEnd) {
		return this.testSenderService.getOrderByPriceRange(priceStart, priceEnd);
	}
	
}
