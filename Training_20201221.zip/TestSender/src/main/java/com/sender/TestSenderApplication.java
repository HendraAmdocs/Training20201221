package com.sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;

@SpringBootApplication
@EnableJms
public class TestSenderApplication {

	public static final String MESSAGE_QUEUE = "order_queue";
	public static JmsTemplate jmsTemplate; 

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(TestSenderApplication.class, args);

		TestSenderApplication.jmsTemplate = context.getBean(JmsTemplate.class);

	}

}
