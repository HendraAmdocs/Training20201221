package com.sender.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sender.TestSenderApplication;
import com.sender.model.Order;
import com.sender.repository.OrderRepository;

@Service
public class TestSenderService {

	@Autowired
	private OrderRepository orderRepository;
	
	public String saveOrUpdateOrder(Order order) {
		System.out.println("--------------------------------------------------------------------------------");
		System.out.println("Order:\n" + order);
		System.out.println("");
		
		System.out.println("Save to H2.");		
		this.orderRepository.save(order);

		System.out.println("Send to message broker.");
		TestSenderApplication.jmsTemplate.convertAndSend(TestSenderApplication.MESSAGE_QUEUE, order);
		System.out.println("--------------------------------------------------------------------------------");
		
		return "Order was saved successfully.";
	}
	
	public List<Order> getAllOrders() {
		List<Order> orders = new ArrayList<Order>();
		this.orderRepository.findAll().forEach(order -> orders.add(order));
		return orders;
	}
	
	public Order getBook(int id) {
		return this.orderRepository.findById(id).get();
	}
	
	public void deleteOrder(int id) {
		this.orderRepository.deleteById(id);
	}
	
	public List<Order> getOrderByPriceRange(int priceStart, int priceEnd) {
		List<Order> orders = new ArrayList<Order>();
		this.orderRepository.findAll().forEach(order -> {
			if (order.getPrice() >= priceStart && order.getPrice() <= priceEnd) {
				orders.add(order);
			}
		});
		return orders;
	}
	
}
