package com.sender.repository;

import org.springframework.data.repository.CrudRepository;

import com.sender.model.Order;

public interface OrderRepository extends CrudRepository<Order, Integer> {

}
