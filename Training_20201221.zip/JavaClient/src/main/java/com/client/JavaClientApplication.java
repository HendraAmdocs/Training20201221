package com.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.client.model.Book;

//@SpringBootApplication
public class JavaClientApplication {

	final static Logger logger = LoggerFactory.getLogger(JavaClientApplication.class);
	
	public static void main(String[] args) {
		ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
		root.setLevel(ch.qos.logback.classic.Level.TRACE);
		
//		SpringApplication.run(JavaClientApplication.class, args);
		

		logger.trace("---------> App start.");

//		logger.trace("------------> Get a book.");
//		
//		RestTemplate restTemplate = new RestTemplate();
//		ResponseEntity<Book> books = restTemplate.getForEntity("http://localhost:8080/books/5434", Book.class);
//		System.out.println(books.getBody());

//		logger.trace("------------> Create a book.");
//		createBook();

//		logger.trace("------------> Update a book.");
//		updateBook();

//		logger.trace("------------> Delete a book.");
//		deleteBook();

//		logger.trace("------------> Get all book.");
//		getAllBooks();

		logger.trace("------------> Get books by price range.");
		getBooksByPriceRange();

		logger.trace("---------> App stop normally.");
		System.exit(0);
	}
	
	private static void createBook() {
		Book book = new Book();
		
		book.setBookId(1);
		book.setBookName("The Famous Five");
		book.setAuthor("Enid Blyton");
		book.setPublisher("Hardie Grant");
		book.setPrice(50);
		
		List<String> distributors = new ArrayList<String>();
		distributors.add("Amazon");
		distributors.add("Alibaba");
		
		book.setDistributors(distributors);
		
		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.postForObject("http://localhost:8080/books/", book, String.class);
		System.out.println(response);
	}

	private static void updateBook() {
		Book book = new Book();
		
		book.setBookId(1);
		book.setBookName("The Famous Five 2nd Edition");
		book.setAuthor("Enid Blyton");
		book.setPublisher("Hardie Grant");
		book.setPrice(55);
		
		List<String> distributors = new ArrayList<String>();
		distributors.add("Amazon");
		distributors.add("Alibaba");
		distributors.add("Gramedia");
		
		book.setDistributors(distributors);
		
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.put("http://localhost:8080/books/", book, String.class);
	}
	
	private static void deleteBook() {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.delete("http://localhost:8080/books/1");
	}
	
	private static void getAllBooks() {
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Book[]> response = restTemplate.getForEntity("http://localhost:8080/books", Book[].class);
		Book[] booksArr = response.getBody();
		List<Book> books = Arrays.asList(booksArr);
		System.out.println(books);
	}
	
	private static void getBooksByPriceRange() {
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Book[]> response = restTemplate.getForEntity("http://localhost:8080/books/70/90", Book[].class);
		Book[] booksArr = response.getBody();
		List<Book> books = Arrays.asList(booksArr);
		System.out.println(books);
	}
	
}
