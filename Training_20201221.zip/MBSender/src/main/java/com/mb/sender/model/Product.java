package com.mb.sender.model;

import java.io.Serializable;

public class Product implements Serializable {
	private static final long serialVersionUID = 2613898619714812005L;
	private int productId;
	private String name;
	private int quantity;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
