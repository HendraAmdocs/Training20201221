package com.mb.sender.config;

public class JMSConfiguration {

}
