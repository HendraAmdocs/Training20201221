package com.mb.sender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;

import com.mb.sender.model.Product;

@SpringBootApplication
@EnableJms
public class MbSenderApplication {

	private static final String MESSAGE_QUEUE = "sender_queue";

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(MbSenderApplication.class, args);

		JmsTemplate jmsTemplate = context.getBean(JmsTemplate.class);

		for (int i = 1; i <= 10; i++) {
			Product product = new Product();
			product.setProductId(i);
			product.setName("Laptop");
			product.setQuantity(i);

			System.out.println("Sending a product [" + i + "]");
			
			jmsTemplate.convertAndSend(MESSAGE_QUEUE, product);
		}
		
		System.exit(0);
	}

}
