package com.books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
