package com.books.model;

import java.util.List;

public class Book {
	private int bookId;
	private String bookName;
	private String author;
	private int price;
	private String publisher;
	private List<String> distributors;
	
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		if (price >= 0) {
			this.price = price;
		} else {
			throw new IllegalStateException("Price is wrong.");
		}
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public List<String> getDistributors() {
		return distributors;
	}

	public void setDistributors(List<String> distributors) {
		this.distributors = distributors;
	}

}
